package week3.day1;

public class TelePhone {
	String str;
	public void makeCall() {
		System.out.println("make call");
	}
	public void receivedCall() {
		System.out.println("receive call");

	}

}
