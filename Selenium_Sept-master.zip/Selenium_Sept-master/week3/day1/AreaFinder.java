package week3.day1;

public class AreaFinder {
	public static void main(String[] args) {
		CalculateArea area = new CalculateArea();
		System.out.println(area.area(10));
		System.out.println(area.area(75.75));
		
	}

}
