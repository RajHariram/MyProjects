package week3.day1;

public class MainPhone {
	
	public static void main(String[] args) {
		MobilePhone mp=new MobilePhone();
		mp.takePhotos();
		mp.makeCall();
		mp.receivedCall();
		TelePhone tp=new TelePhone();
		tp.receivedCall();
		tp.makeCall();
		/*AndroidPhone ap=new AndroidPhone();
		ap.playStore();*/
		
		
		
		
		
		
		
		
	}

}
