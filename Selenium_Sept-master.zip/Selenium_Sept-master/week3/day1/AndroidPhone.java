package week3.day1;

public class AndroidPhone extends MobilePhone{
	
	public void playStore() {
		System.out.println("Appl play store");

	}

}
