package week3.day1;

public class InterfaceImpl implements LearnInterface{

	public void display() {
		//num=num+10;
		System.out.println("display method");
		
	}
	

}
