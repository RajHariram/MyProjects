package week3.day1;

public class CalculateArea {

	public int area(int length) {
		return length*length;
	}
	public double area(double length) {
		return length*length;
	}
	public int area(int length, int breadth) {
		return length*breadth;
	}
}
