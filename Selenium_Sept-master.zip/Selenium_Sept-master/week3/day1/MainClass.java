package week3.day1;

public class MainClass {

	public static void main(String[] args) {
		InterfaceImpl li=new InterfaceImpl();
		li.display();

	}

}
