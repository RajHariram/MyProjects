package week3.day1;

public interface LearnInterface {
	int num=10;
	public void display();
	
	
}
