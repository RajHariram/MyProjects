package week1.day2;

public class LearnString {
	public static void main(String[] args) {
//		String colour = new String("red"); // Object
		
		String text = "Amazon has 24,142 employees";
		String replaceAll = text.replaceAll("[^0-9]", "");
		System.out.println(replaceAll);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		String color = "RED orange yellow"; // Literal
		
		
		
		/*String[] words = color.split(" ");
		System.out.println(words.length);*/
		
		
		
		/*String expectedColor = "RED";
		if (color.startsWith(expectedColor)) {
			System.out.println("Color does match");
		}else {
			System.out.println("Color doesn't match");
		}*/
		
		
		
		
		
		/*int length = color.length();
		char charAt = color.charAt(length - 1);
		System.out.println(charAt);*/
		
		
		
		
		/*String trim = color.trim();
		System.out.println(trim);*/
		
		/*String lowerCase = color.toLowerCase();
		System.out.println(lowerCase);*/
		
		/*String upperCase = color.toUpperCase();
		System.out.println(upperCase);*/
		
		/*int length = color.length();
		System.out.println(length);
		char[] charArray = color.toCharArray();
		for (char c : charArray) {
			System.out.println(c);
		}*/
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	}
}
