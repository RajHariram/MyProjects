package week1.day2;

public class CallMe {
	
	
	public static void display() {
		System.out.println("fn called");
	}

}
