package week1.day2;

public class Reverse {

	public static void main(String[] args) {
		String text = "KoushiK";
		String temp = "";
		char[] array = text.toCharArray();
		/*for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < i; j++) {
				if (array[i] == array[j]) {
					temp = ""+array[i];
				}
			}
		}*/
		System.out.println(text.replaceAll(temp,""));;
		
		
		
		
		/*for (int i = text.length() -1; i >= 0; i--) {
			System.out.print(text.charAt(i));
		}*/






		/*char[] charArray = text.toCharArray();
		for (int i = charArray.length -1; i >= 0; i--) {
			System.out.print(charArray[i]);
		}*/

	}

}




