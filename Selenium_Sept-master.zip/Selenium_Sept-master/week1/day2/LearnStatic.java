package week1.day2;

public class LearnStatic {
	static int num =10;
	/*static {
		System.out.println("Static block");
	}*/
	public static void main(String[] args) {
		
		System.out.println(num);
		
		
		
//		CallMe.display();
		// ClassName.methodName();
		// ClassName.variableName;
	}

}






