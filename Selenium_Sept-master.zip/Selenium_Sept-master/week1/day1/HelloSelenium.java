package week1.day1;

public class HelloSelenium {
	public static void main(String[] args) {
		System.out.println("Welcome");
		int age = 28;
		int salary = 320000;
		long phone = 9999999999L;
		boolean b = true;
		System.out.println(b);
		char c = 'K';
		String name = "Logu";
	}
}








