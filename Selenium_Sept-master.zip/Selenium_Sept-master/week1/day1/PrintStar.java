package week1.day1;

public class PrintStar {

	public static void main(String[] args) {
		for (int i = 1; i <= 10; i++) {
			for (int j = 1; j <=i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
		
		
		
		
		
		
		
		
		
		
		
		
		/*for (int i = 20; i >= 10; i--) {
//			System.out.println(i);
			if (i %2 == 0) {
				System.out.println(i);
			}
		}*/
		
		
		
		
		
		
		
		
	/*for (int i = 100; i >= 1 ; i--) {
			System.out.println(i);
			if(i == 50) {
				break;
			}
		}*/		
	}
}




