package week1.day1;

public class PrintOdd {

	public static void main(String[] args) {
		int number = 3;
		if(number %2 == 0) {
			System.out.println("Even");
		}else {
			System.out.println("Odd");
		}
	}

}



